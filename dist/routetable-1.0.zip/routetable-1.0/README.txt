routetable

PyQt5 views with parser models to extract routing information from log files and compare two files.